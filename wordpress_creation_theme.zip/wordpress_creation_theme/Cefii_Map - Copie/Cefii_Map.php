<?php
/*
Plugin Name: Cefii Map
Description: permet d'insérer des cartes Goggle via un shortcode
Version: 1.0
Author: VR
Text Domain: Cefii_Map
Domain Path: /languages/
*/

if (!class_exists('Cefii_Map')) {
    class Cefii_Map {
        /* Définition de la classe */
        function cefii_map_install() {
            // la variable globale "global $wpdb" permet de se connecter directement à la base de donnée WordPress
            global $wpdb;
            $table_site = $wpdb->prefix . 'cefiimap';
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_site'") != $table_site) {
                $sql = "CREATE TABLE `$table_site` ( `id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `latitude` TEXT NOT NULL , `longitude` TEXT NOT NULL , PRIMARY KEY (`id`))ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
                // fonction WP "dbDelta($sql)" permet d'effectuer une création ou un update 
                dbDelta($sql);
            }
        }

        // suppression de la table lors de la désactivation du plugin n'est pas idéale car on perds alors toutes les données des cartes que l'on souhaitait ajouter
        // function cefii_map_uninstall() {
        //     global $wpdb;
        //     $table_site = $wpdb->prefix . 'cefiimap';
        //     if ($wpdb->get_var("SHOW TABLES LIKE '$table_site'") == $table_site) {
        //         $sql = "DROP TABLE `$table_site`";
        //         $wpdb->query($sql);
        //     }
        // }

        function init() {
            if (function_exists('add_options_page')) {
                add_options_page(
                    'CEFii Map',
                    'CEFii Map',
                    'administrator',
                    dirname(__FILE__),
                    array($this, 'cefii_map_admin_page')
                );
            }
        }

        function cefii_map_admin_page() {}
    }
}

if (class_exists('Cefii_Map')) {
    $inst_map = new Cefii_Map();
}

if (isset($inst_map)) {
    register_activation_hook(__FILE__, array($inst_map, 'cefii_map_install'));
    // register_deactivation_hook(__FILE__, array($inst_map, 'cefii_map_uninstall'));
    add_action('admin_menu', array($inst_map, 'init'));
}